declare module 'react-native-config' {
  export interface NativeConfig {
    API_URL?: string;
    WEB_URL?: string;
    SENTRY_DSN?: string;
  }
  export const Config: NativeConfig;
  export default Config;
}